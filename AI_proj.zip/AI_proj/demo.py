import tkinter as tk
from tkinter import ttk
from collections import deque
import time
import random

# Define the graph representation of the map of Romania
romania_map = {
    'Arad': {'Zerind': 75, 'Sibiu': 140, 'Timisoara': 118},
    'Zerind': {'Arad': 75, 'Oradea': 71},
    'Oradea': {'Zerind': 71, 'Sibiu': 151},
    'Sibiu': {'Arad': 140, 'Oradea': 151, 'Fagaras': 99, 'Rimnicu Vilcea': 80},
    'Timisoara': {'Arad': 118, 'Lugoj': 111},
    'Lugoj': {'Timisoara': 111, 'Mehadia': 70},
    'Mehadia': {'Lugoj': 70, 'Drobeta': 75},
    'Drobeta': {'Mehadia': 75, 'Craiova': 120},
    'Craiova': {'Drobeta': 120, 'Rimnicu Vilcea': 146, 'Pitesti': 138},
    'Rimnicu Vilcea': {'Sibiu': 80, 'Craiova': 146, 'Pitesti': 97},
    'Fagaras': {'Sibiu': 99, 'Bucharest': 211},
    'Pitesti': {'Rimnicu Vilcea': 97, 'Craiova': 138, 'Bucharest': 101},
    'Bucharest': {'Fagaras': 211, 'Pitesti': 101, 'Giurgiu': 90, 'Urziceni': 85},
    'Giurgiu': {'Bucharest': 90},
    'Urziceni': {'Bucharest': 85, 'Hirsova': 98, 'Vaslui': 142},
    'Hirsova': {'Urziceni': 98, 'Eforie': 86},
    'Eforie': {'Hirsova': 86},
    'Vaslui': {'Urziceni': 142, 'Iasi': 92},
    'Iasi': {'Vaslui': 92, 'Neamt': 87},
    'Neamt': {'Iasi': 87}
}

def iddfs(start, goal, depth):
    for limit in range(depth):
        result = dls(start, goal, limit)
        if result is not None:
            return result

def dls(start, goal, limit):
    stack = deque([(start, [start])])
    while stack:
        node, path = stack.pop()
        if node == goal:
            return path
        if len(path) < limit:
            for neighbor in romania_map[node]:
                new_path = path + [neighbor]
                stack.append((neighbor, new_path))
    return None

class RomaniaMap(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Romania Map")
        self.geometry("2000x2000")
        self.configure(bg="sky blue")  # Set initial background color

        # Create header frame
        header_frame = tk.Frame(self, bg="black", padx=20, pady=10)
        header_frame.pack(side=tk.TOP, fill=tk.X)

        # Add header buttons
        home_button = ttk.Button(header_frame, text="Home", command=self.on_home_click)
        home_button.pack(side=tk.LEFT, padx=10)
        about_button = ttk.Button(header_frame, text="About", command=self.on_about_click)
        about_button.pack(side=tk.LEFT, padx=10)
        contact_button = ttk.Button(header_frame, text="Contact", command=self.on_contact_click)
        contact_button.pack(side=tk.LEFT, padx=10)

        # Add search bar
        search_entry = ttk.Entry(header_frame, font=("Arial", 12))
        search_entry.pack(side=tk.LEFT, padx=10, ipady=5)
        search_entry.bind("<FocusIn>", lambda event: event.widget.config(highlightbackground="black", highlightcolor="black", bg="white"))
        search_entry.bind("<FocusOut>", lambda event: event.widget.config(highlightbackground="white", highlightcolor="white", bg="white"))

        # Create footer frame
        footer_frame = tk.Frame(self, bg="black", padx=20, pady=10)
        footer_frame.pack(side=tk.BOTTOM, fill=tk.X)

        # Add footer label
        footer_label = tk.Label(footer_frame, text="AI Project 2024 by Aditi, Juhi, Urja, Smruti, Shreyashi", font=("Arial", 10), fg="white", bg="black")
        footer_label.pack()

        # Create a frame for the dropdowns and button
        controls_frame = tk.Frame(self, bg="sky blue", padx=20, pady=20)
        controls_frame.pack(side=tk.TOP, fill=tk.X)

        # Create source and destination dropdown menus
        self.cities = list(romania_map.keys())

        source_label = tk.Label(controls_frame, text="Source:", font=("Arial", 14), bg="sky blue")
        source_label.pack(side=tk.LEFT, padx=10)
        self.source_var = tk.StringVar()
        self.source_dropdown = ttk.Combobox(controls_frame, textvariable=self.source_var, values=self.cities, font=("Arial", 12), width=15)
        self.source_dropdown.pack(side=tk.LEFT, padx=10)

        dest_label = tk.Label(controls_frame, text="Destination:", font=("Arial", 14), bg="sky blue")
        dest_label.pack(side=tk.LEFT, padx=10)
        self.dest_var = tk.StringVar()
        self.dest_dropdown = ttk.Combobox(controls_frame, textvariable=self.dest_var, values=self.cities, font=("Arial", 12), width=15)
        self.dest_dropdown.pack(side=tk.LEFT, padx=10)

        # Create a submit button with hover effect
        self.submit_button = ttk.Button(controls_frame, text="Submit", command=self.find_path, style="Submit.TButton")
        self.submit_button.pack(side=tk.LEFT, padx=10)

        self.submit_button.bind("<Enter>", self.on_enter)
        self.submit_button.bind("<Leave>", self.on_leave)

        # Create result text area
        result_frame = tk.Frame(self, bg="sky blue", padx=20, pady=20)
        result_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        result_label = tk.Label(result_frame, text="Path:", font=("Arial", 14, "bold"), bg="sky blue")
        result_label.pack(side=tk.TOP, pady=10)

        self.result_text = tk.Text(result_frame, height=10, width=50, font=("Arial", 12))
        self.result_text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Create a style for the submit button
        style = ttk.Style()
        style.configure("Submit.TButton", font=("Arial", 12), foreground="black", background="purple", padding=10)

        # Start background color change loop
        self.change_bg_color()

    def change_bg_color(self):
        colors = ["sky blue", "light blue", "deep sky blue", "light steel blue", "powder blue"]
        while True:
            self.configure(bg=random.choice(colors))
            time.sleep(5)

    def find_path(self):
        source = self.source_var.get()
        dest = self.dest_var.get()
        path = iddfs(source, dest, max_depth)
        if path:
            self.animate_path(path)
        else:
            self.result_text.delete('1.0', tk.END)
            self.result_text.insert(tk.END, "No path found")

    def animate_path(self, path):
        for city in path:
            self.result_text.delete('1.0', tk.END)
            self.result_text.insert(tk.END, city)
            time.sleep(1)
            self.update()  # Force update to show changes

    def on_enter(self, event):
        event.widget['background'] = 'white'
        event.widget['foreground'] = 'purple'

    def on_leave(self, event):
        event.widget['background'] = 'purple'
        event.widget['foreground'] = 'black'

    def on_home_click(self):
        # Add functionality for home button
        print("Home button clicked")

    def on_about_click(self):
        # Add functionality for about button
        print("About button clicked")

    def on_contact_click(self):
        # Add functionality for contact button
        print("Contact button clicked")

if __name__ == "__main__":
    max_depth = 15  # Set the maximum depth for IDDFS
    app = RomaniaMap()
    app.mainloop()

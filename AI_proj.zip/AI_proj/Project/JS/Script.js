// Define the Romania map data
const city = {
  Arad: ['Zerind', 'Sibiu', 'Timisoara'],
  Zerind: ['Arad', 'Oradea'],
  Oradea: ['Zerind', 'Sibiu'],
  Timisoara: ['Arad', 'Lugoj'],
  Lugoj: ['Timisoara', 'Mehadia'],
  Mehadia: ['Lugoj', 'Drobeta'],
  Drobeta: ['Mehadia', 'Craiova'],
  Craiova: ['Drobeta', 'Rimnicu Vilcea', 'Pitesti'],
  Rimnicu_Vilcea: ['Craiova', 'Sibiu', 'Pitesti'],
  Sibiu: ['Arad', 'Oradea', 'Rimnicu_Vilcea', 'Fagaras'],
  Fagaras: ['Sibiu', 'Bucharest'],
  Pitesti: ['Craiova', 'Rimnicu_Vilcea', 'Bucharest'],
  Bucharest: ['Fagaras', 'Pitesti', 'Giurgiu', 'Urziceni'],
  Giurgiu: ['Bucharest'],
  Urziceni: ['Bucharest', 'Hirsova', 'Vaslui'],
  Hirsova: ['Urziceni', 'Eforie'],
  Eforie: ['Hirsova'],
  Vaslui: ['Urziceni', 'Iasi'],
  Iasi: ['Vaslui', 'Neamt'],
  Neamt: ['Iasi']
};

// Function to perform Iterative Deepening Depth-First Search (IDDFS) algorithm
function iddfs(start, goal, maxDepth) {
  // Helper function for depth-limited DFS
  function dls(node, goal, depth) {
    if (depth === 0 && node === goal) {
      return [node];
    } else if (depth > 0) {
      for (const neighbor of city[node]) {
        const result = dls(neighbor, goal, depth - 1);
        if (result !== null) {
          result.unshift(node);
          return result;
        }
      }
    }
    return null;
  }

  // Iterative deepening loop
  for (let depth = 0; depth <= maxDepth; depth++) {
    const result = dls(start, goal, depth);
    if (result !== null) {
      return result;
    }
  }
  return null; // Path not found within maximum depth
}

// Get references to DOM elements
const startCitySelect = document.getElementById('start-city');
const endCitySelect = document.getElementById('end-city');
const submitBtn = document.getElementById('submit-btn');
const solutionSteps = document.getElementById('solution-steps');
const navbar = document.getElementById('navbar');

// Populate city options in the select elements
function populateCityOptions() {
  for (const cityName in city) {
    const option1 = document.createElement('option');
    option1.text = cityName;
    const option2 = document.createElement('option');
    option2.text = cityName;
    startCitySelect.add(option1);
    endCitySelect.add(option2);
  }
}

// Handle submit button click
submitBtn.addEventListener('click', () => {
  const startCity = startCitySelect.value;
  const endCity = endCitySelect.value;
  // Call IDDFS algorithm function
  const steps = iddfs(startCity, endCity, 10); // Maximum depth set to 10
  // Display solution steps
  solutionSteps.innerHTML = '';
  if (steps !== null) {
    steps.forEach((step, index) => {
      const p = document.createElement('p');
      p.textContent = `Step ${index + 1}: Move to ${step}`;
      solutionSteps.appendChild(p);
    });
  } else {
    solutionSteps.textContent = 'No path found within maximum depth';
  }
});

// Populate city options when the page loads
window.addEventListener('load', populateCityOptions);

// Change background color of navbar every 5 seconds
const colors = ['#007bff', '#28a745', '#dc3545', '#ffc107', '#17a2b8'];
let colorIndex = 0;

setInterval(() => {
  navbar.style.backgroundColor = colors[colorIndex];
  colorIndex = (colorIndex + 1) % colors.length;
}, 5000);
